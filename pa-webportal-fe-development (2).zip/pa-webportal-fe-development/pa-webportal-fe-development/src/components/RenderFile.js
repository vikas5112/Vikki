import React from "react";

import pdfIcon from "../assets/images/pdfIcon.png";
import docIcon from "../assets/images/docImg.png";

function RenderFile({ isFileUrl, file, filename, filetype }) {
  if (file) {
    let typeArr = file.type ? file.type?.split("/") : filetype?.split("/");
    if (Array.isArray(typeArr) && typeArr[0] === "image") {
      return (
        <div>
          {file && (
            <img
              src={typeof file === "string" ? file : URL.createObjectURL(file)}
            />
          )}
        </div>
      );
    } else if (Array.isArray(typeArr) && typeArr[0] === "video") {
      return (
        <div>
          <img
            src="https://jbpbucket-dev.s3.amazonaws.com/devjanbask/feed/videoIcon.jpg"
            style={{ width: "100px" }}
          />

          {/*<span>{` ${file.name || filename}`} </span>*/}
        </div>
      );
    } else if (Array.isArray(typeArr) && typeArr[0] === "application") {
      return (
        <div>
          <img
            src={typeArr[1] === "pdf" ? pdfIcon : docIcon}
            style={{ width: "100px" }}
          />

          {/*<span>{` ${file.name || filename}`} </span>*/}
        </div>
      );
    } else {
      return <div>Undefined file type</div>;
    }
  } else {
    return null;
  }
}

export default RenderFile;
