import React, { useState, useEffect } from "react";
import {
  Row,
  Col,
  Container,
  Dropdown,
  OverlayTrigger,
  Tooltip,
  Modal,
} from "react-bootstrap";
import { stateToHTML } from "draft-js-export-html";
import { convertFromRaw } from "draft-js";
import { Link } from "react-router-dom";
import Card from "./Card";
import RenderLike from "../views/dashboard/ui-kit/ui-like";
import user2 from "../assets/images/user/02.jpg";
import user3 from "../assets/images/user/03.jpg";

import p1 from "../assets/images/page-img/p1.jpg";

import p2 from "../assets/images/page-img/p2.jpg";
import p3 from "../assets/images/page-img/p3.jpg";

import { getDate } from "../utilities/time";

const RenderURLDetails = ({ urlDetails, key }) => {
  return (
    <div key={`key-${urlDetails?.url}-${key}`}>
      {urlDetails && (
        <a href={urlDetails?.url} target="_blank">
          <div>
            <img src={urlDetails?.ogImage}></img>
          </div>
          <div className="scrtDx">
            <div className="scrtTitle">{urlDetails?.title}</div>
            <div className="scrtDescription">{urlDetails?.description}</div>
          </div>
        </a>
      )}
    </div>
  );
};

function FeedBlock({ postDetails, handleLike }) {
  let timeObj = getDate(postDetails?.createdAt);

  // function to conevrt raw data back to html to render
  const convertFromJSONToHTML = (text) => {
    try {
      return { __html: stateToHTML(convertFromRaw(text)) };
    } catch (exp) {
      console.log(exp);
      return { __html: "Error" };
    }
  };

  const getUpdatedHtml = ( textEditorData ) => {
    function replaceURLs(message) {
      if (!message) return;
      var urlRegex = /(((https?:\/\/)|(www\.))[^\s]+)/g;
      //console.log(urlRegex,"urlRegex")
      return message.replace(urlRegex, function (url) {
        var hyperlink = url;
        hyperlink = hyperlink.replace("</p>", "");
        if (!hyperlink.match("^https?://")) {
          hyperlink = "http://" + hyperlink;
        }
        return (
          '<a href="' +
          hyperlink +
          '" target="_blank" rel="noopener noreferrer">' +
          url +
          "</a>"
        );
      });
    }
    let text = textEditorData ? convertFromJSONToHTML({entityMap:{},...textEditorData}):"";
    let urlss = text?.__html?.includes("</a>")
      ? null
      : replaceURLs(text.__html);
    if (urlss) {
      text.__html = urlss;
    }
    return text;
  };

  return (
    <Col sm={12}>
      <Card className=" card-block card-stretch card-height">
        <Card.Body>
          <div className="user-post-data">
            <div className="d-flex justify-content-between">
              <div className="me-3">
                <img
                  className="avatar-60 rounded-circle img-fluid"
                  src={postDetails?.created_by?.profile_picture}
                  alt=""
                />
              </div>
              <div className="w-100">
                <div className="d-flex justify-content-between">
                  <div>
                    <h5 className="mb-0 d-inline-block">
                      {postDetails?.created_by?.username}
                    </h5>
                    <p className="mb-0 text-primary">
                      {timeObj.hours > 0
                        ? timeObj.hours > 23
                          ? `on ${timeObj?.timeStart.toDateString()}`
                          : `${Math.floor(timeObj.hours)} hour ago`
                        : `${Math.floor(timeObj.minutes)} min ago`}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-3">
            {postDetails?.text_editor_data ? (
              <>
                <div dangerouslySetInnerHTML={getUpdatedHtml(postDetails?.text_editor_data)}></div>
                <RenderURLDetails />
              </>
            ) : (
              <p>{postDetails?.plain_text}</p>
            )}
          </div>
          <div className="user-post">
            {postDetails?.files.map((file) => (
              <div className=" d-grid grid-rows-2 grid-flow-col gap-3">
                <div className="row-span-2 row-span-md-1">
                  <img
                    src={p2}
                    alt="post1"
                    className="img-fluid rounded w-100"
                  />
                </div>
                <div className="row-span-1">
                  <img
                    src={p1}
                    alt="post2"
                    className="img-fluid rounded w-100"
                  />
                </div>
                <div className="row-span-1 ">
                  <img
                    src={p3}
                    alt="post3"
                    className="img-fluid rounded w-100"
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="comment-area mt-3">
            <div className="d-flex justify-content-between align-items-center flex-wrap">
              <div className="like-block position-relative d-flex align-items-center">
                <div className="d-flex align-items-center">
                  <RenderLike handleLike={handleLike} data={postDetails} />
                </div>
                <div className="total-comment-block">
                  {`${postDetails?.comment_count} Comments`}
                </div>
              </div>
            </div>
            <hr />
            <ul className="post-comments list-inline p-0 m-0">
              <li className="mb-2">
                <div className="d-flex">
                  <div className="user-img">
                    <img
                      src={user2}
                      alt="user1"
                      className="avatar-35 rounded-circle img-fluid"
                    />
                  </div>
                  <div className="comment-data-block ms-3">
                    <h6>Monty Carlo</h6>
                    <p className="mb-0">Lorem ipsum dolor sit amet</p>
                    <div className="d-flex flex-wrap align-items-center comment-activity">
                      <Link to="#">like</Link>
                      <Link to="#">reply</Link>
                      <Link to="#">translate</Link>
                      <span> 5 min </span>
                    </div>
                  </div>
                </div>
              </li>
              <li>
                <div className="d-flex">
                  <div className="user-img">
                    <img
                      src={user3}
                      alt="user1"
                      className="avatar-35 rounded-circle img-fluid"
                    />
                  </div>
                  <div className="comment-data-block ms-3">
                    <h6>Paul Molive</h6>
                    <p className="mb-0">Lorem ipsum dolor sit amet</p>
                    <div className="d-flex flex-wrap align-items-center comment-activity">
                      <Link to="#">like</Link>
                      <Link to="#">reply</Link>
                      <Link to="#">translate</Link>
                      <span> 5 min </span>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
            <form className="comment-text d-flex align-items-center mt-3">
              <input
                type="text"
                className="form-control rounded"
                placeholder="Enter Your Comment"
              />
              <div className="comment-attagement d-flex">
                <Link to="#">
                  <i className="ri-link me-3"></i>
                </Link>
                <Link to="#">
                  <i className="ri-user-smile-line me-3"></i>
                </Link>
                <Link to="#">
                  <i className="ri-camera-line me-3"></i>
                </Link>
              </div>
            </form>
          </div>
        </Card.Body>
      </Card>
    </Col>
  );
}

export default FeedBlock;
