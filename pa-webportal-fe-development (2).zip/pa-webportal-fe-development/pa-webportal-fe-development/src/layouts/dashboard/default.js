import React,{useEffect} from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { useGetConnectionQuery} from '../../store/connection/connectionApiSlice'

//header
import Header from '../../components/partials/dashboard/HeaderStyle/header'

//sidebar
import RightSidebar from '../../components/partials/dashboard/SidebarStyle/rightsidebar'

//sidebar
import Sidebar from '../../components/partials/dashboard/SidebarStyle/sidebar'

//footer
import Footer from '../../components/partials/dashboard/FooterStyle/footer'

//default 
import DefaultRouter from '../../router/default-router'

// share-offcanvas
import ShareOffcanvas from '../../components/share-offcanvas'

//settingoffCanvas
import SettingOffCanvas from '../../components/setting/SettingOffCanvas'
import {
    useLocation
  } from "react-router-dom";

const Default = () => {
    const location = useLocation()
    // console.log(location)
useEffect(()=>{
    
},[])

    const dispatch=useDispatch()
   // const {data}=useGetConnectionQuery()
   // console.log(data,"getConnection")
    useEffect(async()=>{
        //const data=await dispatch(getConnection())
        //console.log(data,"dataaa")
                //dispatch(useGetConnectionQuery())
    },[])
    return (
        <>
                <Sidebar />
                <Header />
                <div className="main-content">
                    <div id="content-page" className="content-page">
                        <DefaultRouter/>
                    </div>
                </div>
               {location.pathname !== "/dashboard/app/userList" && <RightSidebar />}
            <Footer />
            <SettingOffCanvas/>
            <ShareOffcanvas />
        </>
    )
}

export default Default
