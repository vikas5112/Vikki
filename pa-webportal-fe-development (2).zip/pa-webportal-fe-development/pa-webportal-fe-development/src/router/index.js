import React, { useEffect } from "react";

//router
import { Switch, Route, Redirect, useHistory,useLocation } from "react-router-dom";

//layoutpages
import Default from "../layouts/dashboard/default";
import WithoutLeftSidebar from "../layouts/dashboard/without-leftsidebar";
import WithoutRightSidebar from "../layouts/dashboard/without-rightsidebar";
import Layout1 from "../layouts/dashboard/layout-1";
import Simple from "../layouts/dashboard/simple";
//import PrivateRoute from './private-router'
var state={}
const IndexRouters = () => {
  const history = useHistory();
  state = useLocation()?.state;
  const token = localStorage.getItem("token");
  useEffect(() => {
    if (token) {
      history.push("/dashboard");
    } else {
      history.push("/auth/sign-in");
    }
  }, [token]);
  return (
    <>
      {!token ? (
        <Switch>
          <Route path="/errors" component={Simple}></Route>
          <Route path="/extra-pages" component={Simple}></Route>
          <Route path="/auth" component={Simple}></Route>
        </Switch>
      ) : (
        <Switch>
          <Route exact path="/">
            {<Redirect to="/dashboard" />}
          </Route>
          <Route path="/dashboard" component={Default}></Route>
          <Route
            path="/without-leftsidebar"
            component={WithoutLeftSidebar}
          ></Route>
          <Route
            path="/without-rightsidebar"
            component={WithoutRightSidebar}
          ></Route>
          <Route path="/dashboards" component={Layout1}></Route>
        </Switch>
      )}
    </>
  );
};

export default IndexRouters;
