import React, { useState, useEffect } from "react";
import { Row, Col, Container, Form } from "react-bootstrap";
import Card from "../../../components/Card";
import { Link } from "react-router-dom";
import {
  useGetConnectionQuery,
  useUpdateStatusMutation,
} from "../../../store/connection/connectionApiSlice";

import user05 from "../../../assets/images/user/05.jpg";

const ConnectionList = () => {
  const [allConnections, setAllConnections] = useState([]);
  const [displayConnections, setDisplayConnections] = useState([]);
  const { data } = useGetConnectionQuery();
  const [updateStatus] = useUpdateStatusMutation();

  const onHandleSearchChange = async (e) => {
    let connectionSearchData = e.target.value;
    e.preventDefault();
    var tempArr = [];
    allConnections.map((item) => {
      let fullName = item.requester?.username;
      const lData = fullName.toLowerCase();
      if (lData.includes(connectionSearchData.toLowerCase())) {
        tempArr.push(item);
      }
    });

    setDisplayConnections(tempArr);
  };

  const handleBlock = async (id) => {
    const res = await updateStatus({
      id: id,
      status: "blocked",
    });
    if (res?.data?.status === 1) {
      let newList = displayConnections.filter((val) => val._id != id);
      setDisplayConnections(newList);
    }
  };

  useEffect(() => {
    if (data && data?.status === 1 && data?.data?.length > 0) {
      setAllConnections(data?.data);
      setDisplayConnections(data?.data);
    }
  }, [data]);



  
  return (
    <>
      {/* <ProfileHeader title="Friend Lists" img={img3}/> */}

      <Container>
        <Row>
          <Col sm="12">
            <Card>
              <Card.Header className="d-flex justify-content-between">
                <div className="header-title">
                  <h4 className="card-title">Connections ({displayConnections.length})</h4>
                </div>
                <div className="iq-search-bar device-search">
                  <Form action="#" className="searchbox">
                    <div className="search-link">
                      <span className="material-symbols-outlined">search </span>
                    </div>
                    <Form.Control
                      type="text"
                      className="text search-input bg-soft-primary"
                      placeholder="Search Connection"
                      onChange={(event) => onHandleSearchChange(event)}
                    />
                  </Form>
                </div>
              </Card.Header>
              <Card.Body>
                <ul className="request-list list-inline m-0 p-0">
                  {displayConnections.map((val) => (
                    <li className="d-flex align-items-center  justify-content-between flex-wrap">
                      <div className="user-img img-fluid flex-shrink-0">
                        <img
                          src={user05}
                          alt="story-img"
                          className="rounded-circle avatar-40"
                        />
                      </div>
                      <div className="flex-grow-1 ms-3">
                        <h6>{val.requester.username}</h6>
                        {/* <p className="mb-0">40 friends</p> */}
                      </div>
                      <div className="d-flex align-items-center mt-2 mt-md-0">
                        <div
                          className="confirm-click-btn"
                          onClick={() => handleBlock(val?._id)}
                        >
                          <div className="me-3 btn btn-primary rounded confirm-btn">
                            Block
                          </div>
<div
                          
                          className="btn btn-secondary rounded"
                          data-extra-toggle="delete"
                          data-closest-elem=".item"
                        >
                          Message
                        </div>
                          
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default ConnectionList;
