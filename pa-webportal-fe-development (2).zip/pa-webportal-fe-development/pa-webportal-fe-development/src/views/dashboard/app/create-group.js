import React, { useState, useRef, useEffect } from "react";
import {
  Container,
  Row,
  Col,
  Card,
  Tab,
  Form,
  Button,
  Nav,
} from "react-bootstrap";
import { useSelector } from "react-redux";
import { Link, useHistory, useParams } from "react-router-dom";

//image
import img1 from "../../../assets/images/user/11.png";
import { connectionApiSlice } from "../../../store/connection/connectionApiSlice";

const CreateGroup = () => {
  const { i } = useParams();
  const userList = useSelector((state) => state.userList);

  const [groupPic, setGroupPic] = useState({ icon: "", url: "" });
  const [userData, setUserData] = useState({
    is_public: true,
    title: "",
    group_name: "",
    group_image: ""
  });

  const inputRef = useRef(null);

  const history = useHistory();

  // handleUploadProfilePicture()

  const updateUserdetail = () => {
    console.log(userData);

    fetch(
      `https://pa-webportal-api.janbaskplatform-development.com/api/groups/create-group`,
      {
        method: "POST",
        body: JSON.stringify(userData),
        headers: {
          authorization: `Bearer ${localStorage.getItem("token")}`,
          "content-type": "application/json",
        },
      }
    )
      .then((response) => {
        if (response.ok) {
          response.json().then((data) => {
            alert("Group is Created Successfully");
            history.push("/dashboards/app/groups");
          });
        } else {
        }
      })
      .catch((error) => { });
  };

  const handleChange = (e) => {
    if (e.target.id === "group_title") {
      setUserData({ ...userData, title: e.target.value })
    }
    if (e.target.id === "group_description") {
      setUserData({ ...userData, group_description: e.target.value })
    }
    if (e.target.id === "group_type") {
      if (e.target.value === "public") {
        setUserData({ ...userData, is_public: true })
      }
      if (e.target.value === "private") {
        setUserData({ ...userData, is_public: false })
      }
    }
  };

  const handleUpload = (event) => {
    const url = URL.createObjectURL(event.target.files[0])
    setGroupPic({
      icon: event.target.files[0],
      url: url,
    });
    setUserData({ ...userData, group_image: url })
  };

  console.log("userData", userData)

  return (
    <>
      <Container>
        <div className='container' style={{ height: "200px", color: "white" }}>
          <img src='https://www.pasecondarytransition.com/assets21/webpimages/Practices-ban.webp' style={{ width: "100%", height: "100%", borderRadius: "5px" }} />
        </div>
        <Tab.Container defaultActiveKey="first">
          <Row className="mt-3">
            <Col lg={12}>
              {/* <div className="iq-edit-list-data"> */}
              <Tab.Content>
                <Tab.Pane eventKey="first" className="fade show">
                  <Card>
                    <Card.Header className="d-flex justify-content-between">
                      <div className="header-title">
                        <h4 className="card-title">Create a New Group</h4>
                      </div>
                    </Card.Header>
                    <Card.Body>
                      <Form>
                        <Form.Group className="form-group align-items-center">
                          <Col md="12">
                            <div className="profile-img-edit">
                              <img
                                className="profile-pic"
                                src={groupPic?.url ? groupPic?.url : img1}
                                alt="profile-pic"
                              />
                              <div className="p-image">
                                <i
                                  className="ri-pencil-line upload-button text-white"
                                  onClick={() => inputRef.current?.click()}
                                ></i>
                                <input
                                  className="file-upload"
                                  type="file"
                                  ref={inputRef}
                                  accept="image/*"
                                  onChange={(event) => handleUpload(event)}
                                />
                              </div>
                            </div>
                          </Col>
                        </Form.Group>
                        <Row className="align-items-center">
                          <Form.Group className="form-group col-sm-6">
                            <Form.Label
                              htmlFor="first_name"
                              className="form-label"
                            >
                              Group Title:
                            </Form.Label>
                            <Form.Control
                              type="text"
                              className="form-control"
                              id="group_title"
                              //   placeholder={userData?.first_name}
                              onChange={handleChange}
                            />
                          </Form.Group>

                          <Form.Group className="form-group col-sm-6">
                            <Form.Label className="form-label">
                              Group Type:
                            </Form.Label>
                            <Form.Select
                              className="form-select"
                              aria-label="Default select example 2"
                              id="group_type"
                              onChange={handleChange}
                            >
                              <option value="public">Public</option>
                              <option value="private">Private</option>

                            </Form.Select>
                          </Form.Group>

                          <Form.Group className="form-group col-sm-6">
                            <Form.Label
                              htmlFor="last_name"
                              className="form-label"
                            >
                              Group Description:
                            </Form.Label>
                            <Form.Control
                              as="textarea"
                              className="form-control"
                              id="group_description"
                              //   placeholder={userData?.last_name}
                              onChange={handleChange}
                            />
                          </Form.Group>

                        </Row>
                        <Button
                          className="btn btn-primary me-2"
                          onClick={updateUserdetail}
                        >
                          Create
                        </Button>
                        <Link to="/dashboards/app/groups">
                          <Button
                            type="reset"
                            className="btn btn-secondry me-1"
                          >
                            Cancel
                          </Button>
                        </Link>
                      </Form>
                    </Card.Body>
                  </Card>
                </Tab.Pane>
              </Tab.Content>
              {/* </div> */}
            </Col>
          </Row>
        </Tab.Container>
      </Container>
    </>
  );
};

export default CreateGroup;
