import React, { useState } from "react";
import {
  Row,
  Col,
  Form,
  Container,
  Nav,
  Button,
  Table,
  Tab,
} from "react-bootstrap";
import Card from "../../../components/Card";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import "./index.scss";
import { userList as userListActions } from "../../../store/userList/userListSlice";

// images

import user04 from "../../../assets/images/user/04.jpg";
import { preventDefault } from "@fullcalendar/react";
import { useDispatch } from "react-redux";

const UserList = () => {
  const [userList, setUserList] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  const history = useHistory();
  const dispatch = useDispatch();

  const getuserList = () => {
    fetch(
      `https://pa-webportal-api.janbaskplatform-development.com/api/users/get-all-users/${searchTerm}`,
      {
        method: "GET",
        headers: {
          authorization: `Bearer ${localStorage.getItem("token")}`,
          "content-type": "application/json",
        },
      }
    )
      .then((response) => {
        if (response.ok) {
          response.json().then((data) => {
            dispatch(userListActions(data.data));
            setUserList(data.data);
          });
        } else {
        }
      })
      .catch((error) => {});
  };

  console.log("hello")

  const handleSearchTerm = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setSearchTerm(e.target.value);
  };

  const handleActive = (data, id) => {
    fetch(
      `https://pa-webportal-api.janbaskplatform-development.com/api/users/active-deactive-user/${id}/${data}`,
      {
        method: "PATCH",
        headers: {
          authorization: `Bearer ${localStorage.getItem("token")}`,
          "content-type": "application/json",
        },
      }
    )
      .then((response) => {
        if (response.ok) {
          response.json().then((data) => {
            getuserList();
          });
        } else {
        }
      })
      .catch((error) => {});
  };
  const handleAction = (e, i) => {
    const value = e?.target.value;
    if (value === "view") {
      history.push("/dashboard/app/profile");
    }
    if (value === "edit") {
      history.push(`/dashboard/app/profile-edit-by-admin/${i}`);
    }
    if (value === "delete") {
      handleActive(userList[i].is_active ? 0 : 1, userList[i]._id);
    }
  };

  useState(() => {
    getuserList();
  }, []);

  return (
    <>
    
        
      <div className="table_container">
        
        <Card>
              <Card.Header className="d-flex justify-content-between">
          <div>
            <h3 className="table_heading_text">Portal Users</h3>
          </div>
          <div>
            <div className="table_search ">
              <Form action="#" className="searchbox">
                <Link className="search-link" to="#">
                  <span
                    className="material-symbols-outlined"
                    onClick={() => getuserList()}
                  >
                    search
                  </span>
                </Link>
                <Form.Control
                  type="text"
                  className="text search-input bg-soft-primary"
                  placeholder="Search User Here..."
                  onChange={handleSearchTerm}
                />
              </Form>
            </div>
          </div>
          </Card.Header></Card>
        

        <div className="">
          <div id="left-tabs-example" defaultActiveKey="first">
            <div>
              <div className="">
                <div eventKey="first">
                  <Card>
                    <Card.Body className="p-0">
                      <Table responsive className="forum-table mb-0 rounded">
                        <thead className="heading_bg text-white">
                          <tr>
                            <th> Name</th>
                            {/* <th>Last Name</th> */}
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>User Type</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {userList.map((item, i) => {
                            return (
                              <tr className="">
                                <td className="col-lg-2">
                                  <div className="img_name_div">
                                    <img
                                    height={30}
                                    width={30}
                                      loading="lazy"
                                      className=""
                                      src={item.profile_picture ? item.profile_picture : user04 }
                                      alt= ''
                                    />
                                    <div className=" ms-1">
                                      <h6 className="mb-0">
                                        <Link to="/dashboard/app/profile">
                                          <div className="tbl_name">
                                            <span> {item.first_name} </span>
                                            &nbsp;
                                            <span> {item.last_name}</span>
                                          </div>
                                        </Link>
                                      </h6>
                                    </div>
                                  </div>
                                </td>
                                {/* <td className="col-lg-2">{item.last_name}</td> */}
                                <td className="col-lg-2 ms-3">{item.email}</td>
                                <td className="col-lg-2">
                                  <input className="phone" value={item.phone} />
                                </td>
                                <td className="col-lg-2">
                                  {item.is_active ? "active" : "deactivated"}
                                </td>
                                <td className="col-lg-2">
                                  {item.user_type}
                                  {/* <select
                                    className="form-select"
                                    name="choices-multiple-default"
                                    id="choices-multiple-default"
                                    // value={item.user_type}
                                    onChange={(e) => handleUserType(e, i)}
                                  >
                                    <option value="student">Student</option>
                                    <option value="trainer">Trainer</option>
                                    <option value="family">Family</option>
                                    <option value="admin">Admin</option>
                                  </select> */}
                                </td>
                                <td className="edit">
                                  <select
                                    className="form-select"
                                    name="choices-multiple-default"
                                    id="choices-multiple-default"
                                    onChange={(e) => handleAction(e, i)}
                                    required
                                  >
                                    <option value="none">*</option>
                                    {/* <option value="view">View</option> */}
                                    <option value="edit">View/Edit</option>
                                    <option value="delete">
                                      {item.is_active
                                        ? "deactivate"
                                        : "activate"}
                                    </option>
                                  </select>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </Table>
                    </Card.Body>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
     
    </>
  );
};

export default UserList;
