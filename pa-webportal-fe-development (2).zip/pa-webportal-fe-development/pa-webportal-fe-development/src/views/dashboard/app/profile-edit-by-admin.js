import React, { useState, useRef, useEffect } from "react";
import {
  Container,
  Row,
  Col,
  Card,
  Tab,
  Form,
  Button,
  Nav,
} from "react-bootstrap";
import { useSelector } from "react-redux";
import { Link, useHistory, useParams } from "react-router-dom";

//image
import img1 from "../../../assets/images/user/11.png";

const ProfileEditByAdmin = () => {
  const { i } = useParams();
  const userList = useSelector((state) => state.userList);
  
  // const [user,setUser] = useState(userList ? userList.userList[i] : {});
  const [userData, setUserData] = useState(
    userList ? userList.userList[i] : {}
  );

  const inputRef = useRef(null);

  const history = useHistory();

  // handleUploadProfilePicture()

  const updateUserdetail = () => {
    console.log(userData);

    fetch(
      `https://pa-webportal-api.janbaskplatform-development.com/api/users/update-user-details-by-admin`,
      {
        method: "PATCH",
        body: JSON.stringify(userData),
        headers: {
          authorization: `Bearer ${localStorage.getItem("token")}`,
          "content-type": "application/json",
        },
      }
    )
      .then((response) => {
        if (response.ok) {
          response.json().then((data) => {
            alert("User has been updated Successfully");
            history.push("/dashboard/app/userList");
          });
        } else {
        }
      })
      .catch((error) => {});
  };

  const handleChange = (value) => {
    setUserData({ ...userData, [value.target.id]: value.target.value, ["user_id"]: userList.userList[i]._id});
  };

  useEffect(() => {
    setUserData(userList.userList[i]);
  }, [userList]);

  return (
    <>
      <Container>
        <Tab.Container defaultActiveKey="first">
          <Row>
            <Col lg={12}>
              {/* <div className="iq-edit-list-data"> */}
              <Tab.Content>
                <Tab.Pane eventKey="first" className="fade show">
                  <Card>
                    <Card.Header className="d-flex justify-content-between">
                      <div className="header-title">
                        <h4 className="card-title">View or Edit User Detail</h4>
                      </div>
                    </Card.Header>
                    <Card.Body>
                      <Form>
                        <Form.Group className="form-group align-items-center">
                          <Col md="12">
                            <div className="profile-img-edit">
                              <img
                                className="profile-pic"
                                src={userData.profile_picture ? userData.profile_picture : img1}
                                alt="profile-pic"
                              />
                              {/* <div className="p-image">
                                <i
                                  className="ri-pencil-line upload-button text-white"
                                  onClick={() => inputRef.current?.click()}
                                ></i>
                                <input
                                  className="file-upload"
                                  type="file"
                                  ref={inputRef}
                                  accept="image/*"
                                  onChange={(event) => handleUpload(event)}
                                />
                              </div> */}
                            </div>
                          </Col>
                        </Form.Group>
                        <Row className="align-items-center">
                          <Form.Group className="form-group col-sm-6">
                            <Form.Label
                              htmlFor="first_name"
                              className="form-label"
                            >
                              First Name:
                            </Form.Label>
                            <Form.Control
                              type="text"
                              className="form-control"
                              id="first_name"
                              placeholder={userData?.first_name}
                              onChange={handleChange}
                            />
                          </Form.Group>
                          <Form.Group className="form-group col-sm-6">
                            <Form.Label
                              htmlFor="last_name"
                              className="form-label"
                            >
                              Last Name:
                            </Form.Label>
                            <Form.Control
                              type="text"
                              className="form-control"
                              id="last_name"
                              placeholder={userData?.last_name}
                              onChange={handleChange}
                            />
                          </Form.Group>
                          <Form.Group className="form-group col-sm-6">
                            <Form.Label htmlFor="uname" className="form-label">
                              User Name:
                            </Form.Label>
                            <Form.Control
                              type="text"
                              className="form-control"
                              id="uname"
                              placeholder={userData?.username}
                              disabled
                            />
                          </Form.Group>
                          <Form.Group className="form-group col-sm-6">
                            <Form.Label htmlFor="email" className="form-label">
                              Email:
                            </Form.Label>
                            <Form.Control
                              type="text"
                              className="form-control"
                              id="email"
                              placeholder={userData?.email}
                              onChange={handleChange}
                              disabled
                            />
                          </Form.Group>

                          <Form.Group className="form-group col-sm-6">
                            <Form.Label htmlFor="phone" className="form-label">
                              Phone
                            </Form.Label>
                            <Form.Control
                              className="form-control"
                              id="phone"
                              placeholder={userData?.phone}
                              onChange={handleChange}
                            />
                          </Form.Group>

                          <Form.Group className="form-group col-sm-6">
                            <Form.Label className="form-label">
                              UserType:
                            </Form.Label>
                            <Form.Select
                              className="form-select"
                              aria-label="Default select example 2"
                              id="user_type"
                              onChange={handleChange}
                            >
                              <option value="student">Student</option>
                              <option value="trainer">Trainer</option>
                              <option value="family">Family</option>
                              <option value="admin">Admin</option>
                            </Form.Select>
                          </Form.Group>
                        </Row>
                        <Button
                          className="btn btn-primary me-2"
                          onClick={updateUserdetail}
                        >
                          Submit
                        </Button>
                        <Link to="/dashboard/app/userList">
                          <Button
                            type="reset"
                            className="btn btn-secondry me-1"
                          >
                            Cancel
                          </Button>
                        </Link>
                      </Form>
                    </Card.Body>
                  </Card>
                </Tab.Pane>
              </Tab.Content>
              {/* </div> */}
            </Col>
          </Row>
        </Tab.Container>
      </Container>
    </>
  );
};

export default ProfileEditByAdmin;
