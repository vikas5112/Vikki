import React, { useState } from 'react'
import { Row, Col, Container, Form, Button, Image, Alert } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { useHistory } from 'react-router-dom'
import { setUser } from '../../../store/user/action'
import { useSelector, useDispatch } from 'react-redux'
import './index.scss'

//swiper
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Navigation, Autoplay } from 'swiper';

// Import Swiper styles
import 'swiper/swiper-bundle.min.css'
import 'swiper/components/navigation/navigation.scss';

//img
import logo from '../../../assets/images/main_logo.webp'
import login1 from '../../../assets/images/slider1.jpg'
import login2 from '../../../assets/images/slider2.jpg'
import login3 from '../../../assets/images/slider3.jpg'
import { validation } from './formValidation'

// install Swiper modules
SwiperCore.use([Navigation, Autoplay]);

const Recoverypw = () => {
   const [formErrors, setFormErrors] = useState({})
  
   const [userInput, setUserInput] = useState({
     
      email: '',
      new_password: '',
      confirm_password: '',
      otp: '',
   
   })
   const [isValid, setIsValid] = useState({
      call: false,
      success: false,
      msg: 'bbbb'
   })
   const user = useSelector((state) => state.user)
   let history = useHistory()
   const dispatch = useDispatch()

   const handlUserInput = (e, input) => {
      console.log(e, input)
      
      if (input === 'email') {
         setUserInput({ ...userInput, email: e.target.value })
      }
      else if (input === 'password') {
         setUserInput({ ...userInput, new_password: e.target.value })
      }
      else if (input === 'confirm-password') {
         setUserInput({ ...userInput, confirm_password: e.target.value })
      }
      else if (input === 'otp') {
         setUserInput({ ...userInput, otp: e.target.value })
      }
    
   }

   const handleSubmit = (event) => {
      event.preventDefault();
      event.stopPropagation();
      setFormErrors(validation(userInput))
      console.log("submit")
      // const form = event.currentTarget;
      // if (form.checkValidity() === false) {
      //   event.preventDefault();
      //   event.stopPropagation();
      // }

      dispatch(setUser('data'))
   if(Object.keys(validation(userInput)).length === 0) {  
     fetch(`https://pa-webportal-api.janbaskplatform-development.com/api/auth/forgot-password`, {
         method: 'POST',
         headers: {
            'content-type': 'application/json'
         },
         body: JSON.stringify(userInput)
      }).then((response) => {
         if (response.ok) {
            response.json().then((data) => {
              console.log("recoverpw res: ",data)
              setIsValid({ ...isValid, call: true, success: true, msg: data.message })
              //  localStorage.setItem("token", '')
              //  dispatch(setUser(data.data))
               history.push('/auth/sign-in')
               validation("clear error")
            })
         }
         else {
            response.json().then((data)=> {
             setIsValid({
               ...isValid,
               call: true,
               success: false,
               msg: data.message,
             });
            })
            
           }
      })
         .catch((error) => {
            setIsValid({ ...isValid, call: true, success: false, msg: 'Please Try Again' })
            console.log(error)
         })
         validation("clear error")
        }
      
   }
   console.log(userInput)
   return (
      <>
         <section className="sign-in-page">
            <div id="container-inside">
               <div id="circle-small"></div>
               <div id="circle-medium"></div>
               <div id="circle-large"></div>
               <div id="circle-xlarge"></div>
               <div id="circle-xxlarge"></div>
            </div>
            <Container className="p-0 text">
               <Row className="no-gutters">
                  <Col md="6" className="text-center">
                     <div className="sign-in-detail text-white">
                        <Link className="sign-in-logo mb-5" to="#"><Image src={logo} className="img-fluid" alt="logo" /></Link>
                        <div className="sign-slider overflow-hidden text">
                           <Swiper
                              spaceBetween={30}
                              centeredSlides={true}
                              autoplay={{
                                 "delay": 2000,
                                 "disableOnInteraction": false
                              }}
                              className="list-inline m-0 p-0 ">
                              <SwiperSlide>
                                 <Image src={login1} className="img-fluid mb-4" alt="logo" />
                                 <h4 className="mb-1 text">Find new friends</h4>
                                 <p>It is a long established fact that a reader will be distracted by the readable content.</p>
                              </SwiperSlide>
                              <SwiperSlide>
                                 <Image src={login2} className="img-fluid mb-4" alt="logo" />
                                 <h4 className="mb-1 text">Connect with the world</h4>
                                 <p>It is a long established fact that a reader will be distracted by the readable content.</p>
                              </SwiperSlide>
                              <SwiperSlide>
                                 <Image src={login3} className="img-fluid mb-4" alt="logo" />
                                 <h4 className="mb-1 text">Create new events</h4>
                                 <p>It is a long established fact that a reader will be distracted by the readable content.</p>
                              </SwiperSlide>
                           </Swiper>
                        </div>
                     </div>
                  </Col>
                  <Col md="6" className="bg-white pt-5 pt-5 pb-lg-0 pb-5">
                     <div className="sign-in-from">
                        {isValid.call && (isValid.success
                           ? <Alert variant="success">{isValid.msg}</Alert>
                           : <Alert variant="danger">{isValid.msg}</Alert>)
                        }
                        <h1 className="mb-0 text">Recover password</h1>
                        <p>Enter your email address and OTP to set new password.</p>
                        <Form className="mt-4" noValidate onSubmit={handleSubmit}>
                           <Form.Group className="form-group">
                              <Form.Label>Email address</Form.Label>
                              <Form.Control type="email" className="mb-0" id="email" placeholder="Enter email" onChange={(e) => handlUserInput(e, 'email')} required />
                              <p className='errortext'>{formErrors.email}</p>
                           </Form.Group>
                           <Form.Group className="form-group">
                              <Form.Label>OTP</Form.Label>
                              <Form.Control type="number" className="mb-0" id="otp" placeholder="OTP" onChange={(e) => handlUserInput(e, 'otp')} required  />
                              <p className='errortext'>{formErrors.otp}</p>
                           </Form.Group>
                           <Form.Group className="form-group">
                              <Form.Label>New Password</Form.Label>
                              <Form.Control type="password" className="mb-0" id="password" placeholder="Password" onChange={(e) => handlUserInput(e, 'password')} required />
                              <p className='errortext'>{formErrors.new_password}</p>
                           </Form.Group>
                           <Form.Group className="form-group">
                              <Form.Label>Confirm Password</Form.Label>
                              <Form.Control type="password" className="mb-0" id="confirm-password" placeholder="Confirm-Password" onChange={(e) => handlUserInput(e, 'confirm-password')} required />
                              <p className='errortext'>{formErrors.confirm_password}</p>
                           </Form.Group>
                         
                           <div className="d-inline-block w-100">
                             
                              <Button type="submit" className="btn-primary float-start" >Submit</Button>
                           </div>
                         
                                
                        </Form>
                     </div>
                  </Col>
               </Row>
            </Container>
         </section>
      </>
   )
}

export default Recoverypw
