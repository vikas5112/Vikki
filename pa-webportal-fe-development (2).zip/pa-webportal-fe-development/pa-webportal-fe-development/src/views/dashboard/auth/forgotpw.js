import React, { useState } from 'react'
import {Row, Col, Button, Form, Container, Image, Alert} from 'react-bootstrap'
import {Link} from 'react-router-dom'
import { useHistory } from 'react-router-dom'
import './index.scss'

//swiper
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Navigation, Autoplay } from 'swiper';

// Import Swiper styles
import 'swiper/swiper-bundle.min.css'
import 'swiper/components/navigation/navigation.scss';

// img
import logo from '../../../assets/images/main_logo.webp'
import login1 from '../../../assets/images/slider1.jpg'
import login2 from '../../../assets/images/slider2.jpg'
import login3 from '../../../assets/images/slider3.jpg'
import { validation } from './formValidation'

// install Swiper modules
SwiperCore.use([Navigation, Autoplay]);

const Forgotpw = () => {
    const [userInput, setUserInput] = useState({email:''})
    const [formErrors, setFormErrors] = useState({})
    const [isValid, setIsValid] = useState({
        call: false,
        success: false,
        msg: 'bbbb'
     })
   let history =useHistory()

   const handleEmail = (e) => {
    setUserInput({email: e.target.value})
 }

 const recoverpw = (event) =>{
    event.preventDefault();
    event.stopPropagation();
    setFormErrors(validation(userInput))
    console.log("submit")
    // const form = event.currentTarget;
    // if (form.checkValidity() === false) {
    //   event.preventDefault();
    //   event.stopPropagation();
    // }

    if(Object.keys(validation(userInput)).length === 0) { 
        fetch(`https://pa-webportal-api.janbaskplatform-development.com/api/auth/forgot-password-send-otp`, {
       method: 'POST',
       headers: {
          'content-type': 'application/json'
       },
       body: JSON.stringify(userInput)
    }).then((response) => {
       if (response.ok) {
          response.json().then((data) => {
            console.log("forgotpw res: ",data)
         setIsValid({ ...isValid, call: true, success: true, msg: data.message })
            //  localStorage.setItem("token", '')
            //  dispatch(setUser(data.data))
             history.push('/auth/recoverpw')
             validation("clear error")
          })
       }
       else {
        response.json().then((data)=> {
         setIsValid({
           ...isValid,
           call: true,
           success: false,
           msg: data.message,
         });
        })
        
       }
    })
       .catch((error) => {
          setIsValid({ ...isValid, call: true, success: false, msg: 'Please Try Again' })
          console.log(error)
       })
       validation("clear error");}
 }
 console.log(userInput)
    return (
        <>       
            <section className="sign-in-page">
                {/* <div id="container-inside">
                    <div id="circle-small"></div>
                    <div id="circle-medium"></div>
                    <div id="circle-large"></div>
                    <div id="circle-xlarge"></div>
                    <div id="circle-xxlarge"></div>
                </div> */}
                <Container fluid className="p-0">
                    <Row className="no-gutters">
                        <Col md="8" className="text-center pt-5">
                            <div className="sign-in-detail text-white">
                                {/* <Link className="sign-in-logo mb-5" to="#">
                                    <Image src={logo} className="img-fluid" alt="logo"/>
                                </Link> */}
                                {/* <div className="sign-slider overflow-hidden text">
                                    <Swiper 
                                        spaceBetween={30} 
                                        centeredSlides={true} 
                                        autoplay={{
                                        "delay": 2000,
                                        "disableOnInteraction": false }}  
                                        className="list-inline m-0 p-0">
                                        <SwiperSlide>
                                            <Image src={login1} className="img-fluid mb-4" alt="logo"/>
                                            <h4 className="mb-1 text">Find new friends</h4>
                                            <p>It is a long established fact that a reader will be distracted by the readable content.</p>
                                        </SwiperSlide>
                                        <SwiperSlide>
                                            <Image src={login2} className="img-fluid mb-4" alt="logo"/> 
                                            <h4 className="mb-1 text">Connect with the world</h4>
                                            <p>It is a long established fact that a reader will be distracted by the readable content.</p>
                                        </SwiperSlide>
                                        <SwiperSlide>
                                            <Image src={login3} className="img-fluid mb-4" alt="logo"/>
                                            <h4 className="mb-1 text">Create new events</h4>
                                            <p>It is a long established fact that a reader will be distracted by the readable content.</p>
                                        </SwiperSlide>
                                    </Swiper>
                                </div> */}
                            </div>
                        </Col>
                        <Col md="4" className="bg-white pt-5 pt-5 pb-lg-0 pb-5">
                            <div className="sign-in-from text">
                            {isValid.call && (isValid.success
                           ? <Alert variant="success">{isValid.msg}</Alert>
                           : <Alert variant="danger">{isValid.msg}</Alert>)
                        }
                                <div style={{textAlign:"center", paddingLeft:"50px"}}><Image src={logo} className="img-fluid" alt="logo"  /></div>
                                <h3 className="mb-0 text" style={{fontWeight:'600'}}>Reset Password</h3>
                                <p>Enter your email address and we'll send you an OTP to reset your password.</p>
                                <Form className="mt-4">
                                    <Form.Group>
                                        <Form.Label>Email Address</Form.Label>
                                        <Form.Control type="email" className="mb-0" id="exampleInputEmail1" placeholder="Enter Email" onChange={handleEmail}/>
                                        <p className='errortext'>{formErrors.email}</p>
                                    </Form.Group>
                                    <div className="d-inline-block w-100">
                                    <Button variant="primary" type="button" className="float-right mt-3" onClick={recoverpw}>GET OTP</Button>
                                    </div>
                                </Form>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>  
        </>
    )
}

export default Forgotpw
