import { createSlice,createAsyncThunk } from "@reduxjs/toolkit";
// import _ from "lodash";
// import config from "../redux/config.json"
const initialState = {};


export const connectionSlice = createSlice({
  name: "connection",
  initialState,
  reducers: {
    getConnections: async (state, action) => {
        
    },
  },
});

export default connectionSlice.reducer;
