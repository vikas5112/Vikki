import { connectionSlice } from "./reducer";

export const { getConnections,fetchTodos } = connectionSlice.actions;

export default connectionSlice.actions;
