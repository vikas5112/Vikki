import { apiSlice } from "../apiSlice";

export const postApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getPosts: builder.query({
      query: () => ({
        url: "posts/get-all-post/0/1",
        method: "GET",
      }),
    }),
    createPost: builder.mutation({
      query: (data) => ({
        url: "/posts/create-post",
        method: "POST",
        body: data,
      }),
    }),
    feedUpload: builder.mutation({
      query: (data) => ({
        url: "/aws/upload_feed",
        method: "POST",
        body: data,
      }),
    }),
    likePost: builder.mutation({
      query: (data) => ({
        url: "/like/like-post",
        method: "POST",
        body: data,
      }),
    }),
  }),
});

export const {
  useGetPostsQuery,
  useCreatePostMutation,
  useFeedUploadMutation,
  useLikePostMutation,
} = postApiSlice;
