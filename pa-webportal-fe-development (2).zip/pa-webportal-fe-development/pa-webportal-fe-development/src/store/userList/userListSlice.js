import { createSlice } from "@reduxjs/toolkit";
import action from "../connection/action";

const initialState = {
    userList: []
}

const userListSlice = createSlice({
    name: 'userList',
    initialState,
    reducers: {
        userList: (state, action) =>{
            state.userList = action.payload
        }
    }
})


export default userListSlice.reducer
export const {userList,} = userListSlice.actions 
