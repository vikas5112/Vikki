import {createApi,fetchBaseQuery} from "@reduxjs/toolkit/query/react"
import config from "./config.json"

const baseQuery=fetchBaseQuery({
    baseUrl:`${config.WEBPORTAL_URL}/api`,   //Base query
   // credentials:'include', //will send back http query back
    prepareHeaders:(headers,{getState})=>{
        const token=localStorage.getItem('token')
        //getState().auth.token
        if(token){
            headers.set('authorization',`Bearer ${token}`)
        }
        return headers

    }
})
const baseQueryWithReauth=async(args,api,extraOptions)=>{
    const result=await baseQuery(args,api,extraOptions)
    if(result?.error?.status===401){
        //localStorage.removeItem("token");
        localStorage.clear();
        window.location.href = window.location.origin;
        window.location.reload(false);
    }
    return result
}

export const apiSlice=createApi({
    reducerPath:'api',
    baseQuery:baseQueryWithReauth,
    keepUnusedDataFor:2,
    endpoints:builder=>({})
})
