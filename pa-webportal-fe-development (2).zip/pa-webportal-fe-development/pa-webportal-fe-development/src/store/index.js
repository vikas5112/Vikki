
import { configureStore,combineReducers } from '@reduxjs/toolkit';
import settingReducer from './setting/reducers';
import userReducer from './user/reducers';
import userListReducer from './userList/userListSlice'
import {apiSlice} from './apiSlice'
import storage from 'redux-persist/lib/storage';
import { persistReducer, persistStore } from 'redux-persist';
import thunk from 'redux-thunk';

const persistConfig = {
  key: 'root',
  storage,
}
const combinedReducer = combineReducers({ 
  [apiSlice.reducerPath]:apiSlice.reducer,
    setting: settingReducer,
    user:userReducer,
    userList: userListReducer,
})

const rootReducer = (state, action) => {
  if (action.type === 'user/logoutUser') {
    // this applies to all keys defined in persistConfig(s)
    storage.removeItem('persist:root')
    
    state = undefined;
  }
  return combinedReducer(state, action);
};
const persistedReducer = persistReducer(persistConfig, rootReducer)

export const store = configureStore({
  reducer:persistedReducer,
  middleware:getDefaultMiddleware=>getDefaultMiddleware().concat(apiSlice.middleware),
  devTools:true
});

// export default store;

export const persistor = persistStore(store)
