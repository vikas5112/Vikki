import { apiSlice } from "../apiSlice";

export const userApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    login: builder.mutation({
      query: (data) => ({
        url: "/auth/login",
        method: "POST",
        body: { ...data },
      }),
    }),
    getInvitaionCount: builder.query({
      query: () => ({
        url: "users/get-notification-count",
        method: "GET",
      }),
    }),
    getUserDetails: builder.query({
      query: (id) => ({
        url: id ? `users/get-user-details/${id}` : `users/get-user-details`,
        method: "GET",
      }),
    }),
    editUserDetails: builder.mutation({
      query: (data) => ({
        url: "users/update-user-details",
        method: "PUT",
        body: { ...data },
      }),
    }),
    fileUpload: builder.mutation({
        query: (data) => ({
          url: "/aws/upload_file",
          method: "POST",
          body: data ,
        }),
      }),
      changePassword: builder.mutation({
        query: (data) => ({
          url: "/users/change-password",
          method: "PUT",
          body: data ,
        }),
      }),
      getAllUsers: builder.query({
        query: () => ({
          url: `users/get-all-users`,
          method: "GET",
        }),
      }),
  }),
});

export const {
  useLoginMutation,
  useGetUserDetailsQuery,
 
  useEditUserDetailsMutation,
  useFileUploadMutation,
  useChangePasswordMutation,
  useGetAllUsersQuery,
  useGetInvitaionCountQuery
} = userApiSlice;
