import {userSlice} from './reducers'

export const {
   getUser,
   setUser,
   logoutUser
} = userSlice.actions;

// export default userSlice.actions