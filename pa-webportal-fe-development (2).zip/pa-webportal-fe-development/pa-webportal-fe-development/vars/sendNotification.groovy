def call(String buildStatus = 'STARTED') {
 buildStatus = buildStatus ?: 'SUCCESS'

 def color

 if (buildStatus == 'SUCCESS') {
  color = '#47ec05'
  emoji = ':jenkinssuccessful:'
 } else if (buildStatus == 'UNSTABLE') {
  color = '#d5ee0d'
  emoji = ':jenkinsunstable:'
 } else {
  color = '#ec2805'
  emoji = ':jenkinsfail:'
 }


 attachments = [
    [
      "color": color,
      "blocks": [
        [
          "type": "header",
          "text": [
            "type": "plain_text",
            "text": "*ENV:DEVELOPMENT - pa-webportal-fe - PIPELINE BUILD*  ${env.emoji}",
            "emoji": true
          ]
        ],
        [
          "type": "section",
          "fields": [
            [
              "type": "mrkdwn",
              "text": "*Job Name:*\n${env.JOB_NAME}"
            ],
            [
              "type": "mrkdwn",
              "text": "*Build Number:*\n${env.BUILD_NUMBER}"
            ]
          ],
          "accessory": [
            "type": "image",
            "image_url": "https://raw.githubusercontent.com/janbaskrepo/images/main/jenkins.png",
            "alt_text": "Jenkins Icon"
          ]
        ],
        [
          "type": "section",
          "text": [
              "type": "mrkdwn",
              "text": "*Failed Stage Name: * `${env.failedStage}`"
          ],
          "accessory": [
            "type": "button",
            "text": [
              "type": "plain_text",
              "text": "Jenkins Build URL",
              "emoji": true
            ],
            "value": "click_me_123",
            "url": "${env.BUILD_URL}",
            "action_id": "button-action"
          ]
        ],
        [
          "type": "divider"
        ],
        [
          "type": "section",
          "fields": [
            [
              "type": "mrkdwn",
              "text": "*Deployment Name:*\n${deploymentName}"
            ],
            [
              "type": "mrkdwn",
              "text": "*Container Name:*\n${containerName}"
            ]
          ], 
          "accessory": [
            "type": "image",
            "image_url": "https://raw.githubusercontent.com/janbaskrepo/images/main/frontend-main.png",
            "alt_text": " Webportal FrontEnd application"
          ],
        ],

        [
          "type": "section",
          "fields": [
            [
              "type": "mrkdwn",
              "text": "*Application URL:*\n${applicationURL}"
            ],  
            [
              "type": "mrkdwn",
              "text": "*Username: * `devjanbask`\n*Password :* `password`"
            ]
          ],  
          "accessory": [
            "type": "button",
            "text": [
              "type": "plain_text",
              "text": "Application URL",
              "emoji": true
            ],
            "value": "click_me_123",
            "url": "${applicationURL}",
            "action_id": "button-action"
          ]
        ],
        [
          "type": "divider"
        ],
        [
          "type": "section",
          "fields": [
            [
              "type": "mrkdwn",
              "text": "*Git Commit:*\n${GIT_COMMIT}"
            ],
            [
              "type": "mrkdwn",
              "text": "*Git Previous Commit:*\n${GIT_PREVIOUS_COMMIT}"
            ]
          ], 
          "accessory": [
            "type": "image",
            "image_url": "https://raw.githubusercontent.com/janbaskrepo/images/main/gitlab.png",
            "alt_text": "Gitlab Icon"
          ]
        ],
        [
          "type": "section",
          "text": [
              "type": "mrkdwn",
              "text": "*Gitlab Repository Name: * `pa-webportal-fe` \n*Git Branch: * `${GIT_BRANCH}`"
          ],
          "accessory": [
            "type": "button",
            "text": [
              "type": "plain_text",
              "text": "Gitlab Repository URL",
              "emoji": true
            ],
            "value": "click_me_123",
            "url": "${env.GIT_URL}",
            "action_id": "button-action"
          ]
        ],
        [
          "type": "divider"
        ],
        [ 
          "type": "section",
          "text": [          
              "type": "mrkdwn",
              "text": "*Logging instructions:* To check logs for this application, visit *https://log.janbaskplatform.com* \n \nLogin with the credentials provided in the email. Click on *Observability > Logs > Stream*. \n \n For logs of main application: \nIn the search box, enter: *kubernetes.container_name : development-frontend* \n For logs of webportal application: \n In the search box, enter: *kubernetes.container_name : development-frontend-wp*"
          ], 
          "accessory": [
            "type": "image",
            "image_url": "https://raw.githubusercontent.com/janbaskrepo/images/main/efk.jpg",
            "alt_text": "EFK Icon"
          ]
        ]
      ]
    ]
]

 slackSend(iconEmoji: emoji, attachments: attachments)
}
